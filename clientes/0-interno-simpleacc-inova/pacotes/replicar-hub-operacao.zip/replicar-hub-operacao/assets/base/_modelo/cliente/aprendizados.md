# Aprendizados — <Nome do Cliente>

Log do que funciona e do que não funciona com este cliente.

| Data | Aprendizado / decisão | Origem |
| ---------- | --------------------- | ------ |
|            |                       |        |
